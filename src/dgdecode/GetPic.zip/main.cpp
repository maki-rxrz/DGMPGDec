
#include <windows.h>
#include <stdio.h>
#include "AviSynth2.h"

unsigned char BMPHeader[55] =
{
	0x42, 0x4d, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x01, 0x00, 0x18, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x12, 0x0b,
	0x00, 0x00, 0x12, 0x0b, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

// Remember the pic will be flipped
void CreateBitmap(char *szOut, unsigned char *rgb24, int width, int height)
{	int i,j;
	FILE *BMPFile = fopen(szOut, "wb");

	i = fwrite(BMPHeader, 1, 54, BMPFile);
	i += fwrite(rgb24, 1, width * height * 3, BMPFile);

	j = i & 3;

	while (j>0)
	{
		i += fputc(0, BMPFile);
		j--;
	}

        int newwidth = (width);
        int newheight = (height);
        int newi = (i);

	fseek(BMPFile, 2, SEEK_SET);
	fwrite(&newi, sizeof(int), 1, BMPFile);
	fseek(BMPFile, 18, SEEK_SET);
	fwrite(&newwidth, sizeof(int), 1, BMPFile);
	fwrite(&newheight, sizeof(int), 1, BMPFile);
	
	fclose(BMPFile);
}

VideoInfo* (__cdecl *openMPEG2Source)(char*); 
unsigned char* (__cdecl *getRGBFrame)(int);
void (__cdecl *closeVideo)();

void main(int argc, char *argv[])
{
	if ( argc != 4 )
	{
		printf("Usage: GetPic d2vfile frameno output.bmp");
		return;
	}

	char *szD2VFile = argv[1];
	int  frameno    = atoi(argv[2]);
	char *szBMPFile = argv[3];

	HMODULE hDLL = LoadLibrary("dgdecode.dll");

	if ( !hDLL )
	{
		printf("Could not find dgdecode.DLL");
		return;
	}

	openMPEG2Source = (VideoInfo*  (__cdecl *) (char*)) GetProcAddress(hDLL, "openMPEG2Source");
	getRGBFrame = (unsigned char*  (__cdecl *) (int)) GetProcAddress(hDLL, "getRGBFrame");
	closeVideo = (void  (__cdecl *) ()) GetProcAddress(hDLL, "closeVideo");

	if ( !openMPEG2Source || !getRGBFrame || !closeVideo )
	{
		printf("Couldn't get Functions (wrong dgdecode.dll?)");
		return;
	}

	VideoInfo *vi = openMPEG2Source(szD2VFile);
	unsigned char *rgb24 = getRGBFrame(frameno);
	
	if ( vi->width <= 0 )
	{
		printf("Problem?! file doesn't exist?\n");
		return;
	}

	// Ok the bitmap has to be flipped to look "right"
	unsigned char *rgb24flipped = (unsigned char*) malloc(vi->width*vi->height*3);

	for ( int y = vi->height-1, y2 = 0; y >= 0; y-- )
	{
		memcpy(rgb24flipped+(y*vi->width*3), rgb24+(y2*vi->width*3), vi->width*3);
		y2++;
	}

	CreateBitmap(szBMPFile, rgb24flipped, vi->width, vi->height);

	free(rgb24flipped);

	closeVideo();
}

	

